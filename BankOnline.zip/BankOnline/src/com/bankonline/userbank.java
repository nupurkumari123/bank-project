package com.bankonline;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class userbank
 */
@WebServlet("/userbank")
public class userbank extends HttpServlet {
	private static final long serialVersionUID = 1L;
       java.sql.Connection con =null;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException  {
		
	try {
		con = adduser.initializeDatabase();
		
		       PreparedStatement st = con.prepareStatement("insert into addtable values(?,?,?, ?, ? ,?,?, ?, ?)");
		       		
				st.setString(1, request.getParameter("user_id"));
				
				st.setString(2, request.getParameter("user_name"));
				
				st.setString(3, request.getParameter("father_name"));
				
				st.setString(4, request.getParameter("mother_name"));
				
				st.setString(5, request.getParameter("adhhar_no"));
				
				st.setString(6, request.getParameter("pan_no"));
				
				st.setString(7, request.getParameter("email_id"));
				
				st.setString(8, request.getParameter("contact_no"));
				
				st.setString(9, request.getParameter("balance"));
				int count = st.executeUpdate();
				System.out.println("total number of rows affected here" +count);
				
				st.close();
				con.close();
				PrintWriter out = response.getWriter();
				out.println("<html><body><b>successfully inserted" + "</b></body></html>");
	}
	catch(Exception ex)
	{
		ex.printStackTrace();
		System.out.println("exception");
	}
	}

}
