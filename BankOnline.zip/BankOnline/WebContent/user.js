          
  function validate(){
             let name=document.myform.username.value;
            let userid=document.myform.userid.value
            let fathername=document.myform.fathername.value
            let mothername=document.myform.mothername.value;
            let adharno=document.myform.adharno.value;
            let panno=document.myform.panno.value;
            let emailid=document.myform.emailid.value;
            let contactno=document.myform.contactno.value;
            let balance=document.myform.balance.value;
           
            if(name=="")
            {
                alert("username cannot be empty");
                return false;
            }
            if(userid==''){
                 alert("userid cannot be empty");
                return false;
            }

            
            if(fathername==''){
                 alert("Father Name cannot be empty");
                return false;
            }
            
            if(mothername==''){
                 alert("Mother Name cannot be empty");
                return false;
            }
            
            if(adharno==''){
                 alert("Adhar Number cannot be empty");
                return false;
            }
            if(adharno.length<12 || adharno.length>12){
                alert("Please Enter Correct Adhar Number");
                return false;
            }
            if(isNaN(adharno)){
                alert("Please Enter Correct Contact Number")
                return false;
            }
            
            if(panno==''){
                 alert("Pan Number cannot be empty");
                return false;
            }
             if(panno.length<10 || panno.length>10){
                alert("Please Enter Correct Pan Number");
                return false;
            }
            
            if(emailid==''){
                 alert("Email Id cannot be empty");
                return false;
            }
            
            if(contactno==''){
                 alert("Contact Number cannot be empty");
                return false;
            }
            if(isNaN(contactno)){
                alert("Please Enter Correct Contact Number")
                return false;
            }
            if(contactno.length<10 || contactno.length>10){
                alert("Please Enter Correct Contact Number");
                return false;
            }
            
            if(balance==''){
                 alert("Balance cannot be empty");
                return false;
            }
       
                
  }