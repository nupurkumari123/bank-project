package com.marlab;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class demo {

	

		
	  protected static Connection initializeDatabase()
	     throws SQLException, ClassNotFoundException{
		
		String myDriver = "Con.mysql.jdbc.Driver";
		String myUrl = "jdbc:mysql://localhost/adduser";
		String usname= "root";
		String pass= "root";
		 
		Class.forName(myDriver);
		System.out.println("connection");
		Connection con = DriverManager.getConnection(myUrl , usname,pass);
		System.out.println("good");
		
		return con;
		
		
		
	}
			
		}